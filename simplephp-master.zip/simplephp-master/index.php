<?php

echo "<br>Welcome to OpenShift";
echo "<br>OpenShift version 3.7.1";
